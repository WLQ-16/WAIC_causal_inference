# Contributing

Before contributing, please read and follow all guidelines described on the documentation website: [https://FenTechSolutions.github.io/CausalDiscoveryToolbox/html/developer.html](https://FenTechSolutions.github.io/CausalDiscoveryToolbox/html/developer.html)

Thank you! 
