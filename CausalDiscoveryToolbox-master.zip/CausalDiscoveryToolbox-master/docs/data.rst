cdt.data
==============

.. automodule:: cdt.data
.. currentmodule:: cdt.data

CausalPairGenerator
---------------------
.. autoclass:: CausalPairGenerator
   :members:


AcyclicGraphGenerator
-----------------------
.. autoclass:: AcyclicGraphGenerator
   :members:

load_dataset
---------------------
.. autofunction:: load_dataset
