class EnsembleEstModels:
    def __init__(self) -> None:
        pass