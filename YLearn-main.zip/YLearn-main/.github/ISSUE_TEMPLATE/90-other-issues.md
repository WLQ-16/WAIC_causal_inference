---
name: Other Issues
about: Use this template for any other non-support related issues
labels: 'type:others'

---

This template is for miscellaneous issues not covered by the other issue categories.

